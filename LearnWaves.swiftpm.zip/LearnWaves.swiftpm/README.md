#  LearnWaves

Hi, I'm Iago! I'm completely passionate and curious about everything that involves music, so I decided to make this year's App Playground on this theme.

This Playground explains what sound waves are, their properties and how they relate to music with incredible interactions to enhance the experience!

For a better experience:

- Run the project on iPhones 12, 13, 14 or 15 (Pro and Pro Max included), on iOS16.0 or higher
- Please don't change the iPhone's audio output while running the project!

