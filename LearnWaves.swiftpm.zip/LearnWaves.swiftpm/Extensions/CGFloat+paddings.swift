//
//  CGFloat+paddings.swift
//
//
//  Created by Iago Ramos on 24/02/24.
//

import Foundation

extension CGFloat {
    static let horizontalPadding: Self = 16
}
