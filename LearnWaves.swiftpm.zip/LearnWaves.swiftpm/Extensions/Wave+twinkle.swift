//
//  Wave+twinkle.swift
//
//
//  Created by Iago Ramos on 24/02/24.
//

import Foundation

extension Wave {
    static let twinkle = Wave(notes: Note.twinkle(), amplitude: 1, scale: 30)
}
